package com.company;

public class Main {

    public static void main(String[] args) {
        int i;
        int j;
        /*int[][] board = new int[8][8];
        board [0][0] = 0;
        board [0][1] = 1;
        board [1] [0] = 2;
        for (x = 0; x<8; x++){
            for (y=0; y>8; y++){
    }
    }System.out.print(x+" "+y); */
        int[][] arr = new int[8][8];
        int spot = 0;

        for (i = 0; i < 8; i++) {
            for (j = 0; j < 8; j++) {
                //arr[i][j]=1+j+i;
                System.out.print(arr[i][j] + " ");
            }
            System.out.println();


        }

}
}
